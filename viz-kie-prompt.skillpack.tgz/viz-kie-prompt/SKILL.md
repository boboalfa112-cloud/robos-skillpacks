---
name: viz-kie-prompt
version: 1.2.0
category: viz
description: "Construieste promptul JSON corect (8+2 campuri) pentru orice generare prin MCP-ul kie.ai (Veo3, Nano Banana, Seedream, Runway Aleph, Suno), citit obligatoriu de tool-kie-mcp inainte de kie_image/kie_video/kie_music."
capability: "Construire prompt structurat (JSON, campuri fixe) pentru generare media AI prin kie.ai: imagine, video cu audio, editare, muzica. Vocabular de camera, straturi audio, reguli de pronuntie, specificatii per model."
triggers: []
context_loads: []
inputs:
  - cerere in limbaj natural pentru o scena/imagine/clip (required)
  - kind (image | video | music, derivat din intent, optional)
outputs:
  - obiect JSON cu campurile schema, gata de pasat ca `input` la tool-ul MCP corespunzator
tier: core
---

# viz-kie-prompt, Construire de prompturi pentru kie.ai

## Scop

Construieste promptul corect, ca obiect JSON cu campuri fixe, pentru orice generare media prin
MCP-ul kie.ai. `tool-kie-mcp` citeste acest skill inainte de orice apel `kie_image`, `kie_video`
sau `kie_music`, ca promptul trimis sa fie complet si verificabil, nu o fraza libera scrisa din
memoria modelului. Fara triggere proprii: nu raspunde direct la cereri ale operatorului, il
foloseste `tool-kie-mcp` ca pas intermediar obligatoriu.

## ATENTIE, citeste inainte de orice video Veo3 cu voce non-engleza

Daca operatorul cere un clip `kie_video` (`veo3`/`veo3_fast`) cu dialog/voce intr-o limba non-engleza
(romana inclusiv), citeste OBLIGATORIU intai
[references/modele-kie.md](references/modele-kie.md), sectiunea „AVERTISMENT OBLIGATORIU: voce
non-engleza pe Veo3". Pe scurt: testat pe 5 generari reale (2026-09-22), pronuntia iese aleatorie
indiferent de formularea promptului (diacritice, ritm, accent explicit) -- nu reformula promptul de
mai multe ori sperand la un rezultat mai bun. Solutia care functioneaza (voce ElevenLabs separata +
resincronizare buze cu `volcengine/video-to-video-lip-sync` pe kie.ai, ~$0.60 total) e detaliata
acolo, cu comenzile exacte.

## Inputuri / outputuri

- Input: cererea operatorului in limbaj natural pentru o scena, imagine sau clip.
- Output: obiect JSON cu schema din [references/schema-prompt.md](references/schema-prompt.md),
  gata de pasat direct ca `input` la tool-ul MCP corespunzator.
- Fisierele intermediare (variante respinse, drafturi) nu se salveaza pe disc; promptul aprobat
  merge direct in apelul MCP.

## Constrangeri

- **Niciun camp lipsa.** Un prompt caruia ii lipseste un camp obligatoriu nu pleaca la generare
  (schema completa in `schema-prompt.md`). Campul `mediu` se omite doar cand in cadru nu e text.
- **Operatorul aproba inainte de trimitere.** Construiesc promptul, dar cel care decide daca pleaca
  la kie.ai e operatorul, nu eu, exceptie doar daca a cerut explicit "trimite direct".
- **Cost vizibil inainte de generarile scumpe.** Video Veo3 ($2/8s) sau un `kie_compare` cu mai
  multe modele se anunta cu suma inainte de apel, conform `tool-kie-mcp`.
- **Continutul generat cu AI care se publica poarta mentiune legala** (Articolul 50 AI Act, in
  vigoare din 2 august 2026): raspunderea e a operatorului care publica, nu a mea, dar semnalez o
  data, cand promptul produce ceva destinat publicarii, ca materialul are nevoie de marcaj.

## Quality bar

- Testul rapid: daca promptul ar putea descrie la fel de bine zece imagini foarte diferite, nu e
  gata. Un prompt bun descrie o singura imagine sau un singur clip.
- `stil_si_paleta` nu se reinventeaza per cadru in acelasi proiect: se ia o data (din
  `brand/design-tokens.md` daca operatorul lucreaza pe un brand, altfel din primul cadru aprobat)
  si se lipeste identic in restul cadrelor din acelasi video.
- Pentru clipuri cu voce: diacriticele din replica sunt obligatorii (notatie fonetica, nu
  ortografie), niciodata ghilimele, tonul intr-un cuvant sau doua, sunetul descris pozitiv, nu
  prin negatie. Detalii complete in `schema-prompt.md`.

## Gate-uri in ordine

1. Construiesc promptul din cererea operatorului, completand campurile lipsa cu propuneri (nu le
   las goale tacit, nu le las la latitudinea modelului de generare).
2. Arat promptul complet operatorului, cu modelul kie.ai recomandat si costul estimat
   (`references/modele-kie.md`).
3. Astept aprobarea explicita.
4. Abia dupa aprobare, promptul pleaca la tool-ul MCP (`kie_image` / `kie_video` / `kie_music`)
   prin `tool-kie-mcp`.

## Referinte

- [references/schema-prompt.md](references/schema-prompt.md): schema JSON completa (8+2 campuri),
  cele 4 reguli de aur, regula pronuntiei si a celor trei straturi audio.
- [references/vocabular-camera.md](references/vocabular-camera.md): unghiuri, planuri, miscari de
  camera, ce comunica fiecare.
- [references/modele-kie.md](references/modele-kie.md): specificatii si limite per model kie.ai
  real (veo3, veo3_fast, nano-banana-2, seedream-v5-lite, runway-aleph, suno-v5), reguli de
  prompting pentru imagine.
- [references/stiluri-si-cazuri-de-utilizare.md](references/stiluri-si-cazuri-de-utilizare.md):
  reveal de produs (CGI, fara oameni) si sabloane de video viral/entertainment, mapate pe aceeasi
  schema de 8+2 campuri.

## Invatare

Corectiile primite de la operator nu se scriu in acest fisier. Se scriu in context/learnings.md,
sectiunea `## viz-kie-prompt` (protocolul Mistake -> Rule din CLAUDE.md); routerul le injecteaza
automat la urmatoarea rulare. Ce e deja notat: `node scripts/learnings-get.js viz-kie-prompt`.
