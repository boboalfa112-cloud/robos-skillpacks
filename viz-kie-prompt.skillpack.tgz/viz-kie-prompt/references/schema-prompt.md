# Schema de prompt: cele 8+2 campuri, cele 4 reguli de aur

Distilat din biblioteca robOS de prompting video (`00-regula-operativa.md`,
`02-structura-8-puncte.md`, `06-veo3-playbook.md`, `07-audio-voce-si-dialog.md`) si din
"The Ultimate VEO 3 Prompt Playbook" (MrPuzzles). Fisierul asta e sursa completa pentru cine
foloseste doar MCP-ul kie.ai, fara acces la restul bibliotecii.

## Testul rapid, inainte de orice

Daca promptul ar putea descrie la fel de bine zece imagini foarte diferite, nu e gata. Un prompt
bun descrie o singura imagine sau un singur clip, nu o categorie de imagini.

## Formatul: JSON, nu fraza

Se scrie ca obiect cu chei fixe. Motivul nu e stilistic: un obiect cu campuri fixe se verifica
determinist, o fraza libera nu.

```json
{
  "subiect": "",
  "actiune": "",
  "cadru": "",
  "miscare_camera": "",
  "lumina": "",
  "mediu": "",
  "stil_si_paleta": "",
  "restrictii": ["no text", "no subtitles"]
}
```

| # | Camp | Ce raspunde | Greseala tipica |
|---|---|---|---|
| 1 | `subiect` | Cine sau ce, descris ultra-specific | "o masina" in loc de "o masina sport rosie, decapotabila, clasica" |
| 2 | `actiune` | Ce face, cu verb si ritm | Subiect care doar "exista" in cadru, static si mort |
| 3 | `cadru` | Unghiul si tipul de plan | Lipsa, deci modelul alege un plan mediu plat |
| 4 | `miscare_camera` | Static, pan, dolly-in, tracking, handheld | Lipsa, deci cadrul e intepenit |
| 5 | `lumina` | Sursa, temperatura, directia | "bine luminat", care nu inseamna nimic |
| 6 | `mediu` | Locul, vremea, atmosfera | Fundal generic, care se vede ca fundal generic |
| 7 | `stil_si_paleta` | Stilul vizual plus culorile | Lasat la voia modelului, fiecare cadru arata din alt film |
| 8 | `restrictii` | Ce NU vrei in cadru | Lipsa, deci apare text ilizibil sau oameni nedoriti |

Campul 6 (`mediu`) se omite doar cand in cadru nu e text, restul sunt obligatorii.

Pentru un clip generat (nu imagine statica) se adauga doua campuri:

```json
  "timeline": ["[0-3s] ...", "[3-6s] ...", "[6-8s] ..."],
  "audio": { "dialog": "", "sfx": "", "ambient": "" }
```

Durata din `timeline` trebuie sa corespunda exact duratei cerute la generare (kie.ai/Veo3
genereaza clipuri de 8 secunde per apel; clipuri mai lungi se fac din mai multe generari lipite).

## Cele 4 reguli de aur

Vin din generari ratate, nu din teorie. Se incalca si se plateste imediat (fiecare generare e
platita la momentul acceptarii task-ului de kie.ai).

1. **Fara ghilimele in prompt, niciodata.** Ghilimelele fac modelul sa scrie replica pe ecran, ca
   subtitrare arsa in imagine. Se scrie natural, dupa doua puncte, fara ghilimele romanesti sau
   englezesti.
2. **Tonul se da in unul sau doua cuvinte** (somnoros, entuziasmat, surprins), nu prin indicatii
   lungi de regie sau stare interioara a personajului.
3. **Sunetul se descrie pozitiv, niciodata prin negatie.** Nu "fara muzica", ci exact ce se aude.
   Negatiile nu functioneaza si produc artefacte audio.
4. **Personajele se descriu explicit ca adulti.** Modelele dezactiveaza silentios sunetul pentru
   personaje care par minori. Valabil si pentru animale sau mascote, descrise ca exemplare adulte.

## Cele trei straturi audio, niciodata amestecate

| Strat | Ce contine | Exemplu |
|---|---|---|
| `dialog` | cine vorbeste, in ce limba, cu ce ton, ce spune | femeia spune cald si primitor, in limba romana: Bine ati venit |
| `sfx` | sunete punctuale, legate de o actiune din cadru | fosnet subtil de material cand se misca putin |
| `ambient` | fundalul sonor continuu al scenei | atmosfera linistita de birou, muzica instrumentala discreta |

Un prompt cu voce care are doar `dialog`, fara `sfx` si fara `ambient`, produce o voce care
pluteste peste tacere, se aude ca inregistrare de birou, nu ca scena.

Format exact al campului `dialog`: `cine` + `cum` (tonul, un cuvant sau doua) + `in ce limba` +
`:` + replica, fara ghilimele.

> femeia spune cald si primitor, in limba romana: Bine ati venit in salon, unde va oferim o gama
> variata de servicii.

## Regula pronuntiei: diacriticele decid cum suna

Modelul pronunta exact ce scrii.

1. **Diacriticele sunt obligatorii in replica.** "Buna ziua, ce mai faceti?" cu diacritice se
   citeste corect. Fara diacritice se citeste cu a si i seci, sunet de robot strain care incearca
   romaneste. Diacriticele nu sunt ortografie aici, sunt notatie fonetica.
2. **Un cuvant englezesc scris englezeste va fi pronuntat englezeste.** Pentru pronuntia romaneasca
   a unui termen tehnic intr-o replica romaneasca, se scrie cum se aude: `deploy` devine `diploi`,
   `workflow` devine `uorcflou`. Invers, pentru accent englezesc corect, cuvantul ramane scris
   englezeste, nu se romanizeaza.
3. **Testul e ascultarea, nu citirea.** Un nume propriu, un acronim sau o adresa web se verifica la
   prima generare si se rescrie fonetic daca a iesit gresit. Nu se presupune corect din prima.

## Cand vocea NU vine din model

Modelul de video genereaza vocea odata cu imaginea, sincronizata pe buze. Cand se vrea o voce
constanta in tot proiectul, sau control fin pe intonatie, alternativa e o voce generata separat
(ex. ElevenLabs) montata peste clipul mut. Vocea din model ramane potrivita pentru clipurile in
care personajul chiar se vede vorbind catre camera.

## Regula de consecventa (stil)

Descrierea de stil si paleta se salveaza o data si se lipeste identica in fiecare cadru al
aceluiasi proiect. Nu se rescrie din memorie intre cadre. Modelul se pierde vizual cand formularea
se schimba de la un cadru la altul, chiar daca ideea ramane aceeasi, iar rezultatul arata ca luat
din videoclipuri diferite.

## Consecventa personajului (cand exista un personaj recurent)

Diferita de consecventa de stil de mai sus: aici e vorba de acelasi personaj (om, animal, mascota)
care trebuie sa arate identic in mai multe scene ale aceluiasi proiect, nu doar tonul vizual.

Cinci detalii se aleg o data si se repeta identic in `subiect`, in fiecare scena:

1. **Specie / rasa**: om, urs, extraterestru, robot, maimuta etc.
2. **Trasaturi fizice**: culoarea blanii/parului, tonul pielii, culoarea ochilor, marimea.
3. **Tinuta / accesorii**: esarfa, rucsac, casca, ochelari.
4. **Fata / expresie de baza**: zambet, aer trist, incruntat.
5. **Stilul vocii**: accent, ton, gen, atitudine (relevant doar cand personajul vorbeste).

Descrierea completa a personajului se salveaza o data (in afara promptului, ca notita) si se
lipeste identic la inceputul campului `subiect` de fiecare data. Nu se rescrie din memorie, exact
ca la regula de stil de mai sus.

Ce confunda modelul, concret:
- Schimbarea formularii intre scene, chiar daca descrie acelasi lucru.
- Adaugarea sau eliminarea la intamplare a accesoriilor.
- Descrierea a prea multe trasaturi diferite de la o scena la alta.
- Omiterea trasaturii principale intr-o scena din mijlocul seriei.

Animalele si personajele fictive sunt mai usor de mentinut consistente decat oamenii (mai putine
trasaturi fine de fata care pot varia).

## Restrictii explicite, cand se aplica

- `no text`, `no subtitles`: modelele nu randeaza text lizibil. Text pe ecran se pune separat,
  in postprocesare, nu se cere modelului de generare.
- `no people`: cand se vrea obiect sau mediu curat, fara persoane in cadru.
- Ghilimelele in jurul unei replici declanseaza subtitrare arsa in imagine (vezi reguli de aur).
