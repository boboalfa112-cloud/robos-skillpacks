# Specificatii per model, prin MCP-ul kie.ai

Sursa de adevar pentru rutare si cost: `tool-kie-mcp/SKILL.md`. Fisierul asta adauga doar ce
conteaza pentru scrierea promptului, nu duplica tabelul de rutare.

## Video: veo3 si veo3_fast

- **Durata**: 8 secunde per generare, fix. Un video mai lung se face din mai multe generari lipite
  ulterior (nu se cere kie.ai un singur clip mai lung).
- **Rezolutie**: 720p nativ, cu upscaler catre 1080p disponibil.
- **Audio**: genereaza trei straturi deodata, dialog (sincronizat pe buze), ambient, efecte. Vezi
  `schema-prompt.md` pentru formatul exact al campului `audio`.
- **Watermark**: SynthID invizibil, permanent in fisier, nu se poate dezactiva (diferit de un
  watermark vizibil, care poate fi oprit din interfata).
- **veo3**: calitate mare, cost $2.00 / 8s. Foloseste pentru rezultatul final, dupa ce promptul e
  deja testat.
- **veo3_fast**: cost $0.30 / 8s. Foloseste pentru testarea structurii promptului inainte de
  generarea finala scumpa, sau cand bugetul o cere.
- Camera fizica se simuleaza realist: pan, tilt, zoom, dolly, chiar si drone shot, miscarea e
  constienta de fizica (obiectele se misca natural, cu greutate).
- Stilul se schimba instant prin campul `stil_si_paleta`: film cinematic, anime, animatie 3D,
  format vintage, doar cerand explicit.

## Imagine: nano-banana-2 si seedream-v5-lite

- **nano-banana-2**: calitate mare, pana la 4K ($0.09), potrivit pentru imagine cinematica sau
  editare cu imagine de referinta (`image_input`).
- **seedream-v5-lite**: rapid, 1K ($0.04), potrivit pentru variante multiple sau teste rapide de
  compozitie inainte de varianta finala.
- **Editeaza, nu regenera**: daca o imagine e 80% corecta, promptul urmator cere schimbarea
  specifica ("schimba iluminarea la apus, fa textul albastru neon"), nu regenereaza totul de la
  zero.
- **Limbaj natural, propozitii complete**, nu liste de cuvinte separate prin virgula. "Masina cool,
  neon, oras, noapte, 8k" produce rezultate slabe fata de o propozitie completa cu subiect, actiune
  si context.
- **Fii specific pe materialitate**: nu "o femeie", ci "o femeie eleganta in varsta, purtand un
  costum vintage in stil Chanel". Descrie texturile explicit: finisaj mat, otel periat, catifea
  moale.
- **Consistenta personaj**: pana la 14 imagini de referinta (6 cu fidelitate ridicata), cu
  declaratie explicita gen "pastreaza trasaturile faciale exact ca in Imaginea 1".

## AVERTISMENT OBLIGATORIU: voce non-engleza pe Veo3 (testat pe romana) e nesigura, indiferent de prompt

**Citeste asta INAINTE sa scrii al doilea prompt pentru acelasi clip cu voce non-engleza.** Testat direct,
2026-09-22: 4 generari `veo3_fast` cu ACELASI text de baza, variind DOAR formularea (diacritice, ritm
"rar si apasat", instructiune explicita "native Romanian accent, not foreign"): 3 din 4 au iesit cu
cuvinte contopite/pronuntie proasta, 1 singura a iesit curata. Testat si pe `veo3` normal ($2/8s, nu doar
`veo3_fast`) cu acelasi prompt: exact aceeasi problema. **Nu e o problema de formulare, e varianta
aleatorie a modelului.** Nu mai pierde bani pe a 5-a/a 6-a reformulare de prompt.

**Cauza confirmata din surse externe** (nu presupunere): Google recunoaste oficial pe forumul de suport
ca "Veo genereaza dialogul si audio-ul holistic... asignarea nu e garantata" chiar cu trasaturi de voce
specificate explicit ([support.google.com/gemini/thread/398455099](https://support.google.com/gemini/thread/398455099/veo-3-1-dialogue?hl=en)).
Comunitatea `r/VEO3` confirma acelasi tipar: "VEO has a tendency to match the accent with the speaker's
physical appearance and the environment, regardless of what you prompt it"
([reddit.com/r/VEO3/comments/1nu1dvt](https://www.reddit.com/r/VEO3/comments/1nu1dvt/help_honing_in_on_voice_accents_and_dialects/)).
Adica Veo3 alege accentul dupa cum arata personajul si mediul din poza, nu (doar) dupa text.

**Alternativa netestata azi, de luat in calcul**: Google Flow (`labs.google/flow`), interfata oficiala
Google pentru Veo3 (diferita de API-ul kie.ai folosit aici) -- posibil sa se comporte altfel pe limbi
non-engleze, fiindca e prima-parte, nu un wrapper. Nu am comparat direct azi; daca cineva testeaza,
adauga rezultatul aici.

**Solutia care chiar functioneaza, testata si confirmata pe un clip real:**

1. Genereaza clipul normal cu Veo3/veo3_fast, cu tot promptul (subiect/actiune/cadru/etc. + dialog) --
   conteaza doar imaginea si miscarea rezultate, ignora vocea lui, oricat de proasta ar iesi.
2. Genereaza vocea separat, curat, cu ElevenLabs (`skills/content-offer-video/lib/elevenlabs-tts.js
   --text "..." --voice <id> --out fisier.mp3`, sau `kie_speech` cu model `elevenlabs-tts`). **Pe cont
   ElevenLabs free merg DOAR vocile `premade`** (verifica cu `GET https://api.elevenlabs.io/v2/voices`,
   filtreaza `category: "premade"`) -- vocile `professional`/library (multe voci native pe alte limbi,
   posibil si romana) dau `402 paid_plan_required` pe cont free. Verificat prin transcriere programatica
   (WhisperX, `tool-transcription`), nu prin ascultare: pronuntia iese aproape perfecta, inclusiv
   diacritice corecte, chiar cu voce premade in alta limba de baza (testat cu "Bella", accent american,
   model `eleven_multilingual_v2`).
3. Resincronizeaza buzele din clipul Veo3 pe noua voce cu modelul **`volcengine/video-to-video-lip-sync`**
   de pe kie.ai (~$0.04/secunda, confirmat `GET https://api.kie.ai/api/v1/models`). **Acest model NU e
   inregistrat inca in wrapper-ul MCP `@ulmeanuadrian/kie-mcp`** (`kie_models` nu-l listeaza) -- se
   apeleaza direct API-ul kie.ai (aceeasi cheie `KIE_API_KEY` din `.env`), EXCEPTIE explicita de la
   regula "doar tool-uri MCP" din `tool-kie-mcp/SKILL.md`, autorizata de operator dupa ce i s-a explicat
   clar de ce e nevoie de ea:
   - Video si audio trebuie sa fie URL-uri publice -- urca-le intai cu tool-ul MCP `kie_upload`.
   - `POST https://api.kie.ai/api/v1/jobs/createTask`, header `Authorization: Bearer $KIE_API_KEY`, body:
     `{"model": "volcengine/video-to-video-lip-sync", "input": {"video_url": "...", "audio_url": "...",
     "mode": "lite"}}` (`mode: "basic"` adauga scene detection/speaker ID, inutil pentru un singur
     vorbitor).
   - Status: `GET https://api.kie.ai/api/v1/jobs/recordInfo?taskId=<id_primit>` pana `state: "success"`,
     rezultatul e in `resultJson.resultUrls[0]`.

Cost total testat pe un clip de 8s: ~$0.30 (`veo3_fast`) + $0 (ElevenLabs, credit free) + ~$0.30
(lip-sync) = **~$0.60**, fata de $2,80 pierduti pe 5 regenerari Veo3 succesive fara sa rezolve nimic
(3x `veo3_fast` + 1x `veo3` la $2 incercand variante de prompt pentru accent, plus prima regenerare de
ritm). Daca operatorul cere explicit "fa-mi un video cu veo3" in orice limba non-engleza, semnaleaza
avertismentul asta INAINTE de prima generare, nu dupa a treia incercare esuata.

## Editare video: runway-aleph

Cost $0.40-$1.50, folosit pentru modificari pe un video deja existent (nu generare de la zero).
Promptul descrie DOAR schimbarea ceruta, nu re-descrie toata scena.

## Muzica: suno-v5

Cost $0.10, genereaza muzica cu vocala. Promptul descrie genul, tempo-ul, starea si, daca exista
versuri, versurile explicit (fara ghilimele, aceeasi regula ca la dialogul din video).

## Cand se compara mai multe modele

`kie_compare` genereaza acelasi prompt pe 3-4 modele deodata, cost = suma fiecarui model in parte.
Se foloseste cand nu e clar care model se potriveste stilului cerut, niciodata ca implicit.

## Legatura cu schema de prompt

Toate modelele de mai sus primesc promptul construit dupa schema din
[schema-prompt.md](schema-prompt.md) (campuri JSON fixe). Modelele de imagine ignora campurile
`timeline` si `audio`; modelele de video le cer pe amandoua.
