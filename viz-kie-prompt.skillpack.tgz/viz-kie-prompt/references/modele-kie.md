# Specificatii per model, prin MCP-ul kie.ai

Sursa de adevar pentru rutare si cost: `tool-kie-mcp/SKILL.md`. Fisierul asta adauga doar ce
conteaza pentru scrierea promptului, nu duplica tabelul de rutare.

## Video: veo3 si veo3_fast

- **Durata**: 8 secunde per generare, fix. Un video mai lung se face din mai multe generari lipite
  ulterior (nu se cere kie.ai un singur clip mai lung).
- **Rezolutie**: 720p nativ, cu upscaler catre 1080p disponibil.
- **Audio**: genereaza trei straturi deodata, dialog (sincronizat pe buze), ambient, efecte. Vezi
  `schema-prompt.md` pentru formatul exact al campului `audio`.
- **Watermark**: SynthID invizibil, permanent in fisier, nu se poate dezactiva (diferit de un
  watermark vizibil, care poate fi oprit din interfata).
- **veo3**: calitate mare, cost $2.00 / 8s. Foloseste pentru rezultatul final, dupa ce promptul e
  deja testat.
- **veo3_fast**: cost $0.30 / 8s. Foloseste pentru testarea structurii promptului inainte de
  generarea finala scumpa, sau cand bugetul o cere.
- Camera fizica se simuleaza realist: pan, tilt, zoom, dolly, chiar si drone shot, miscarea e
  constienta de fizica (obiectele se misca natural, cu greutate).
- Stilul se schimba instant prin campul `stil_si_paleta`: film cinematic, anime, animatie 3D,
  format vintage, doar cerand explicit.

## Imagine: nano-banana-2 si seedream-v5-lite

- **nano-banana-2**: calitate mare, pana la 4K ($0.09), potrivit pentru imagine cinematica sau
  editare cu imagine de referinta (`image_input`).
- **seedream-v5-lite**: rapid, 1K ($0.04), potrivit pentru variante multiple sau teste rapide de
  compozitie inainte de varianta finala.
- **Editeaza, nu regenera**: daca o imagine e 80% corecta, promptul urmator cere schimbarea
  specifica ("schimba iluminarea la apus, fa textul albastru neon"), nu regenereaza totul de la
  zero.
- **Limbaj natural, propozitii complete**, nu liste de cuvinte separate prin virgula. "Masina cool,
  neon, oras, noapte, 8k" produce rezultate slabe fata de o propozitie completa cu subiect, actiune
  si context.
- **Fii specific pe materialitate**: nu "o femeie", ci "o femeie eleganta in varsta, purtand un
  costum vintage in stil Chanel". Descrie texturile explicit: finisaj mat, otel periat, catifea
  moale.
- **Consistenta personaj**: pana la 14 imagini de referinta (6 cu fidelitate ridicata), cu
  declaratie explicita gen "pastreaza trasaturile faciale exact ca in Imaginea 1".

## Editare video: runway-aleph

Cost $0.40-$1.50, folosit pentru modificari pe un video deja existent (nu generare de la zero).
Promptul descrie DOAR schimbarea ceruta, nu re-descrie toata scena.

## Muzica: suno-v5

Cost $0.10, genereaza muzica cu vocala. Promptul descrie genul, tempo-ul, starea si, daca exista
versuri, versurile explicit (fara ghilimele, aceeasi regula ca la dialogul din video).

## Cand se compara mai multe modele

`kie_compare` genereaza acelasi prompt pe 3-4 modele deodata, cost = suma fiecarui model in parte.
Se foloseste cand nu e clar care model se potriveste stilului cerut, niciodata ca implicit.

## Legatura cu schema de prompt

Toate modelele de mai sus primesc promptul construit dupa schema din
[schema-prompt.md](schema-prompt.md) (campuri JSON fixe). Modelele de imagine ignora campurile
`timeline` si `audio`; modelele de video le cer pe amandoua.
