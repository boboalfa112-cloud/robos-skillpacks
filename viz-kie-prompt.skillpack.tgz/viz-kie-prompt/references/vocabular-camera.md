# Vocabular de camera: unghi, plan, miscare

Folosit la campurile `cadru` si `miscare_camera` din schema de prompt. Sursa: "The Ultimate VEO 3
Prompt Playbook" (MrPuzzles) + biblioteca robOS de prompting video.

## Unghi (camera angle), ce comunica

| Unghi | Cuvant-cheie in prompt | Comunica |
|---|---|---|
| Close-up | `close-up shot of` | Emotie, detaliu de fata |
| Wide | `wide-angle view` | Personaj plus context complet |
| Low angle | `shot from below` | Putere, dominatie |
| High angle | `shot from above` | Vulnerabilitate, mic |
| Over-the-shoulder | `OTS shot of` | Conversatie, perspectiva |
| Bird's-eye | `top-down shot` | Harta, ansamblu |
| First-person | `first-person POV` | Imersiv, stil vlog |
| Dutch angle | `tilted shot, horizon slanted` | Tensiune, disconfort |
| Worm's-eye | `worm's eye shot from near the ground` | Dramatism |

## Plan (cat arati din scena)

- **Wide**: situeaza scena, personaj plus context complet.
- **Medium**: echilibru intre personaj si context.
- **Close-up**: emotie, expresie faciala.
- **Extreme close-up**: un singur detaliu, construieste intensitate.
- **Two-shot**: doua persoane in cadru, sugereaza relatie.
- **POV**: imersiune, prima persoana.
- **Selfie**: personal, direct, stil creator de continut.
- **Tracking**: urmareste actiunea in miscare.

## Miscare de camera

`static` (fara miscare), `pan` (rotire orizontala), `tilt` (rotire verticala), `tracking`
(urmareste subiectul), `dolly in` / `dolly out` (camera se apropie/departeaza fizic), `crane` sau
`jib` (miscare pe verticala, deasupra scenei), `zoom` (apropiere optica, nu fizica), `handheld`
(instabilitate naturala, senzatie de reportaj).

## Cand promptul e slab vs puternic

Diferenta nu e lungimea textului, e ca promptul puternic raspunde explicit la: cine, ce face, de
unde priveste camera, ce lumina, ce stil, ce miscare, ce culori.

- **Slab**: "A soldier standing in a war zone" → rezultat rigid, nenatural, arata ca dintr-un joc
  video.
- **Puternic**: "An injured soldier crouched down on a burned battlefield. The camera slowly moves
  closer from above. Smoke drifts upward behind him. The scene feels intense, with dim orange
  sunset light fading. The style is rough and cinematic, like a war film. The soldier is breathing
  hard and glancing around, clearly in pain. The colors are deep and somber, burnt orange tones
  mixed with dark grays."

Un prompt care numeste doar subiectul, fara restul campurilor completate, produce exact senzatia
de ieftin, indiferent cat de detaliat descrii subiectul in sine.
