# Stiluri si cazuri de utilizare: reveal de produs si video viral/entertainment

Astea nu sunt campuri noi, sunt **tipare de continut** care se scriu tot cu schema din
[schema-prompt.md](schema-prompt.md) (cele 8+2 campuri). Fisierul asta arata cum se mapeaza un
tip de cerere frecvent pe schema deja existenta, ca sa nu se inventeze o schema noua per caz.

## Reveal de produs (CGI, fara oameni)

Cerere tipica: cineva vrea un clip in care un produs "se asambleaza" din particule/lumina/fum si
se aseaza pe o suprafata, stil reclama high-end, fara actori.

Mapare pe schema:

| Camp | Continut tipic pentru reveal de produs |
|---|---|
| `subiect` | Produsul, descris exact (nume, tip, materiale, culori) |
| `actiune` | Cum se formeaza/asambleaza: "se materializeaza din particule de lumina si se aseaza usor" |
| `cadru` | De obicei close-up sau orbital, rar wide |
| `miscare_camera` | Orbit lent, dolly-in, sau zoom lent pe detalii |
| `lumina` | Accent de lumina colorata (neon, aurie), umbre moi |
| `mediu` | Spatiu digital abstract, platforma reflectorizanta, camera intunecata |
| `stil_si_paleta` | "CGI, cinematic, lucios, futurist" plus paleta specifica brandului |
| `restrictii` | `["no people", "no text"]` de obicei |

Exemplu (adaptat, nu literal din nicio sursa cu drepturi):

```json
{
  "subiect": "o pereche de casti wireless premium, finisaj alb lucios",
  "actiune": "castile se materializeaza din unde de sunet albastre stralucitoare si se aseaza usor pe o suprafata de marmura",
  "cadru": "close-up extrem pe carcasa, apoi orbit larg",
  "miscare_camera": "orbit lent 360 de grade in jurul produsului",
  "lumina": "stralucire albastra rece, reflexii nete pe marmura",
  "mediu": "platforma plutitoare deasupra unui peisaj digital abstract, noapte",
  "stil_si_paleta": "cinematic, ultra slow motion, finisaj lucios, futurist, hiper-realist",
  "restrictii": ["no people", "no text"]
}
```

## Video viral / entertainment (selfie-vlog, comedie, ASMR)

Cerere tipica: cineva vrea un clip amuzant sau captivant pentru TikTok/Shorts/Reels, nu continut
educativ sau reclama serioasa. Registru diferit, aceeasi schema.

Cinci sabloane frecvente, fiecare cu ce se pune tipic in `subiect`/`actiune`/`restrictii`:

1. **Selfie-vlog de creatura fantastica**: `subiect` = creatura descrisa complet (specie, culoare,
   trasaturi, vezi si consecventa de personaj din `schema-prompt.md`), `actiune` = tine camera la
   distanta de brat, stil vlog, reactioneaza la ceva din jur. `cadru` = selfie-style, usor inclinat.
   `restrictii` = `["no subtitles"]`.
2. **ASMR (obiect taiat/manipulat)**: `subiect` + `actiune` descriu obiectul si taietura exacta,
   `cadru` = extreme close-up, `lumina` = calda, moale. `audio.sfx` descrie sunetul satisfacator
   exact (nu generic). `restrictii` = `["no music", "no talking"]`.
3. **Comedie robot/mascota la birou sau in oras**: `subiect` = personajul descris consecvent,
   `actiune` = activitate banala dusa la extrem, `audio.dialog` cu ton plat sau exagerat, un cuvant
   sau doua de ton (vezi regula tonului din `schema-prompt.md`).
4. **Animale la sport**: `subiect` = animalul in echipament sportiv, `mediu` = arena/stadion cu
   spectatori, `audio.ambient` = galagie de multime + sunete specifice sportului.
5. **Interviu stradal absurd**: doi `subiect`-i (reporter + intervievat), `audio.dialog` scrie
   intrebarea SI raspunsul, fiecare cu propriul ton.

Toate cele cinci folosesc exact campurile din `schema-prompt.md`, inclusiv cele trei straturi
audio si regula fara ghilimele. Diferenta fata de continut educativ/serios e doar registrul de
`stil_si_paleta` si `actiune` (mai jucaus, mai exagerat), nu structura.

## Cand se foloseste care

- Educativ/tutorial/brand serios → schema simpla, `stil_si_paleta` fixat din brand, fara umor.
- Reveal de produs → tabelul de mai sus, aproape intotdeauna `no people`.
- Continut de entertainment/viral → unul din cele cinci sabloane, registru jucaus asumat explicit
  de operator inainte de scriere (nu se alege implicit).
